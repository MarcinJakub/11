const wynik = document.querySelector('#wynik');
const btn = document.querySelector('button');

btn.addEventListener(`click`, function(){
    let liczba1 = document.querySelector('#liczba1');
    let liczba2 = document.querySelector('#liczba2');
    let iloraz;
    let wynik_tekst ="";
    if(Number(liczba2.value)==0){
        wynik_tekst = "Nie można dzielić przez zero!"
        wynik.innerHTML = wynik_tekst;
    }
    else{
        iloraz = (Number(liczba1.value) / Number(liczba2.value))
        wynik_tekst = `
            dzielna = ${liczba1.value} <br>
            dzielnik = ${liczba2.value} <br>
            iloraz = ${iloraz} <br>
            iloraz zaokrąglony do dwóch miejsc po przecinku = ${iloraz.toFixed(2)};`

            wynik.innerHTML = wynik_tekst;
    }
})