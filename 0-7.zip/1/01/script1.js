

let liczba1 = prompt("Wprowadź pierwszą liczbę");
let liczba2 = prompt("Wprowadź drugą liczbę");

liczba1 = Number(liczba1)
liczba2 = Number(liczba2)


let wynik = liczba1 + liczba2;

document.write(liczba1 + " + " + liczba2 + " = " + wynik);

