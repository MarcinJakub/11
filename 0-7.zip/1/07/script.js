const wynik = document.querySelector('#wynik');
const btn = document.querySelector('button');

btn.addEventListener(`click`,function(){
    let a = document.querySelector('#a');
    let b = document.querySelector('#b');

    a = parseInt(a.value);
    b = parseInt(b.value);

    let suma = a + b;
    let roznica = a - b;
    let iloczyn = a * b;
    let iloraz;
    let reszta;

    if(b === 0)
    {
        iloraz = "Nie dzielimy przez zero!"
    }
    else
    {
        iloraz = ~~(a/b);
        reszta = a%b;
    }

    let wynik_tekst = `
        Suma = ${suma} <br>
        Różnica = ${roznica} <br>
        Iloczyn = ${iloczyn} <br>
        Iloraz = ${iloraz}<br>
        Reszta z dzielenia = ${reszta}`
        wynik.innerHTML = wynik_tekst;


})