

const wynik = document.querySelector('#wynik');
const btn = document.querySelector('button');

btn.addEventListener('click', function(){

    let a = Number(document.querySelector('#liczba_a').value);
    let b = Number(document.querySelector('#liczba_b').value);
    let c = Number(document.querySelector('#liczba_c').value);
    let d = Number(document.querySelector('#liczba_d').value);
    
    let suma = a + b + c + d;
    let srednia = suma/4;


    let wynik_tekst = `
                       a = ${a}<br> 
                       b = ${b}<br>
                       c = ${c}<br>
                       d = ${d}<br>
                       
                       średnia = ${srednia}<br>`
    wynik.innerHTML = wynik_tekst;
})