let minimum = document.querySelector('#min');
let maks = document.querySelector('#max');

let wynik = document.querySelector('#wynik');
let btn = document.querySelector('button');

btn.addEventListener('click',function(){

    let min = parseInt(minimum.value);
    let max = parseInt(maks.value);

    if (min<max && min>0) {
        let w1 = Math.floor(Math.random() * (max - min + 1) + min);
        let w2 = Math.floor(Math.random() * (max - min + 1) + min);
        let w3 = Math.floor(Math.random() * (max - min + 1) + min);
        let w4 = Math.floor(Math.random() * (max - min + 1) + min);
        let w5 = Math.floor(Math.random() * (max - min + 1) + min);


        wynik.innerHTML = `w1 = ${w1}<br>
                           w2 = ${w2}<br>
                           w3 = ${w3}<br>
                           w4 = ${w4}<br>
                           w5 = ${w5}<br>
                                
                           Suma liczb: ${w1} + ${w2} + ${w3} + ${w4} + ${w5} = ${w1+w2+w3+w4+w5}<br>
                           Iloczyn liczb: ${w1} * ${w2} * ${w3} * ${w4} * ${w5} = ${w1*w2*w3*w4*w5}<br>
                           Średnia liczb: ${(w1+w2+w3+w4+w5)/5}`
    }
    else{
        wynik.innerHTML = `Uwaga! <b>Min</b> musi być mniejsze od <b>max</b> i większe od zera.`
    }
})
