let time = document.querySelector('#sec');
let wynik = document.querySelector('#wynik');
let btn = document.querySelector('button');

btn.addEventListener('click', function(){

    let liczba = parseInt(time.value)

    let g = Math.floor(liczba/3600);
    let sec_cale = liczba%3600;
    let m = Math.floor(sec_cale/60);
    let s = sec_cale%60;


    let wynik_tekst = `Wynik: Godziny: ${g}<br> 
                       Minuty: ${m}<br> 
                       Sekundy: ${s}`;
    wynik.innerHTML = wynik_tekst;
})