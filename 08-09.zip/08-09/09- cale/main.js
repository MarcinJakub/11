let cal = document.querySelector('#cale');
let wynik = document.querySelector('#wynik');
let btn = document.querySelector('button');

btn.addEventListener('click', function(){
    let cale = parseInt(cal.value);
    let mm = cale * 25.3995

    wynik.innerHTML = `<h1>${cale} cal</h1> jest równe <h1>${mm} milimetrów.</h1>`
})