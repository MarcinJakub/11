let cale = document.querySelector('#cale');
let wynik = document.querySelector('#wynik');
let btn = document.querySelector('button');

btn.addEventListener('click', function(){
    let cale = parseInt(cale.value);
    let mm = math.floor(25.3995/cale)
})